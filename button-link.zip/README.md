# button-link
A small module for creating linked image/rich buttons
